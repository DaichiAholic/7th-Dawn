﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended;
using MonoGame.Extended.Screens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DuskAndDawn
{
    public class BaseBuilding : GameScreen
    {
        private Game1 Game1 => (Game1)Game;
        private readonly PlayerState _playerState;

        private const int MaxRoomLevel = 3;

        // Grouped into two rows so the house layout reads as two floors, like a real
        // building cutaway - purely a visual grouping, doesn't change any game logic.
        private static readonly BaseRoomType[] UpperFloorRooms =
        {
            BaseRoomType.Infirmary, BaseRoomType.Barrack, BaseRoomType.Archive
        };

        private static readonly BaseRoomType[] GroundFloorRooms =
        {
            BaseRoomType.Storage, BaseRoomType.Workshop, BaseRoomType.Kitchen
        };

        private static IEnumerable<BaseRoomType> AllRooms => UpperFloorRooms.Concat(GroundFloorRooms);

        private readonly Dictionary<BaseRoomType, Button> _roomButtons = new Dictionary<BaseRoomType, Button>();
        private Button _endDayButton;
        private string _statusLog = "";
        private MouseState _previousMouse;

        // ---- Hover state (UI feedback only, no game-logic effect) ----
        private BaseRoomType? _hoveredRoom;
        private bool _isEndDayHovered;

        // ---- Resource "pop" animation state ----
        // Tracks the last-seen value of each resource so a change (from an upgrade)
        // can trigger a brief pop-then-settle animation on that resource's count.
        private int _lastFood, _lastPlanks, _lastScraps;
        private float _foodPopTimer, _planksPopTimer, _scrapsPopTimer;
        private const float ResourcePopDuration = 0.25f;

        // ---- House cutaway layout constants (1280x720 canvas) ----
        private static readonly RectangleF HouseWall = new RectangleF(140, 222, 1000, 418);
        private static readonly RectangleF Ground = new RectangleF(0, 640, 1280, 80);
        private static readonly Vector2 RoofApex = new Vector2(640, 90);
        private static readonly Vector2 RoofBaseLeft = new Vector2(100, 224);
        private static readonly Vector2 RoofBaseRight = new Vector2(1180, 224);

        private const float PanelWidth = 280f;
        private const float PanelHeight = 140f;
        private static readonly float[] PanelX = { 180f, 500f, 820f };
        private const float UpperRowY = 252f;
        private const float GroundRowY = 432f;

        public BaseBuilding(Game game, PlayerState playerState) : base(game)
        {
            _playerState = playerState;
        }

        public override void Initialize()
        {
            base.Initialize();

            // Seeds with the real current mouse state instead of a blank default, so a click
            // still held down from the previous screen doesn't read as a brand-new click here.
            // (This screen was the one place still missing this fix.)
            _previousMouse = Mouse.GetState();

            for (int i = 0; i < UpperFloorRooms.Length; i++)
            {
                var bounds = new RectangleF(PanelX[i], UpperRowY, PanelWidth, PanelHeight);
                _roomButtons[UpperFloorRooms[i]] = new Button(bounds, UpperFloorRooms[i].ToString());
            }

            for (int i = 0; i < GroundFloorRooms.Length; i++)
            {
                var bounds = new RectangleF(PanelX[i], GroundRowY, PanelWidth, PanelHeight);
                _roomButtons[GroundFloorRooms[i]] = new Button(bounds, GroundFloorRooms[i].ToString());
            }

            _endDayButton = new Button(new RectangleF(490, 655, 300, 55), "End the Day");

            // Snapshot starting resource values so the first frame never reads as a "change"
            // and fires a false pop animation.
            _lastFood = _playerState.Food;
            _lastPlanks = _playerState.Planks;
            _lastScraps = _playerState.Scraps;
        }

        public override void Update(GameTime gameTime)
        {
            if (_playerState.IsGameOver)
            {
                ScreenManager.ReplaceScreen(new GameOverScreen(Game));
                return;
            }

            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;
            _foodPopTimer = MathF.Max(0f, _foodPopTimer - dt);
            _planksPopTimer = MathF.Max(0f, _planksPopTimer - dt);
            _scrapsPopTimer = MathF.Max(0f, _scrapsPopTimer - dt);

            var mouse = Mouse.GetState();

            // Hover state is recomputed every frame (not just on click) so panels can
            // react as soon as the mouse enters them, not only when clicked.
            _hoveredRoom = null;
            foreach (var room in AllRooms)
            {
                if (_roomButtons[room].Contains(mouse.X, mouse.Y))
                {
                    _hoveredRoom = room;
                    break;
                }
            }
            _isEndDayHovered = _endDayButton.Contains(mouse.X, mouse.Y);

            if (InputChecker.IsNewLeftClick(mouse, _previousMouse))
            {
                foreach (var room in AllRooms)
                {
                    if (_roomButtons[room].Contains(mouse.X, mouse.Y))
                    {
                        TryUpgrade(room);
                    }
                }

                if (_endDayButton.Contains(mouse.X, mouse.Y))
                {
                    ScreenManager.ShowScreen(new PreparationScreen(Game, _playerState), ScreenTransitions.FadeTransition(GraphicsDevice));
                }
            }

            // Any resource change this frame (from an upgrade spend) triggers that
            // resource's pop animation.
            if (_playerState.Food != _lastFood)
            {
                _foodPopTimer = ResourcePopDuration;
                _lastFood = _playerState.Food;
            }
            if (_playerState.Planks != _lastPlanks)
            {
                _planksPopTimer = ResourcePopDuration;
                _lastPlanks = _playerState.Planks;
            }
            if (_playerState.Scraps != _lastScraps)
            {
                _scrapsPopTimer = ResourcePopDuration;
                _lastScraps = _playerState.Scraps;
            }

            _previousMouse = mouse;
        }

        private void TryUpgrade(BaseRoomType room)
        {
            int level = _playerState.RoomLevels[room];
            if (level >= MaxRoomLevel)
            {
                _statusLog = $"{room} is already at max level.";
                return;
            }

            var (food, planks, scraps) = GetUpgradeCost(room, level);

            if (_playerState.TrySpend(food, planks, scraps))
            {
                _playerState.RoomLevels[room] = level + 1;
                _statusLog = $"{room} upgraded to level {level + 1}.";
            }
            else
            {
                _statusLog = $"Not enough resources to upgrade {room} (needs {food} Food, {planks} Planks, {scraps} Scraps).";
            }
        }

        private (int food, int planks, int scraps) GetUpgradeCost(BaseRoomType room, int currentLevel)
        {
            int tier = currentLevel;
            return room switch
            {
                BaseRoomType.Storage => (0, 3 * tier, 3 * tier),
                BaseRoomType.Workshop => (0, 2 * tier, 4 * tier),
                BaseRoomType.Infirmary => (3 * tier, 0, 3 * tier),
                BaseRoomType.Kitchen => (6 * tier, 0, 0),
                BaseRoomType.Barrack => (3 * tier, 3 * tier, 0),
                BaseRoomType.Archive => (0, 0, 6 * tier),
                _ => (0, 0, 0)
            };
        }

        // ---------- Draw ----------

        public override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(176, 214, 230)); // daytime sky - Day stays safe and bright by design

            var spriteBatch = Game1.SpriteBatch;
            var font = Game1.Font;
            spriteBatch.Begin();


            DrawRooms(spriteBatch, font);
            DrawFooter(spriteBatch, font);
            DrawEndDayButton(spriteBatch, font);
            DrawHopeBar(spriteBatch, font);
            DrawResourceIcons(spriteBatch, font);

            spriteBatch.End();
        }



        private void DrawRooms(SpriteBatch spriteBatch, SpriteFont font)
        {
            spriteBatch.DrawString(font, "Upper Floor", new Vector2(HouseWall.X + 40, HouseWall.Y + 8), new Color(100, 80, 60));
            spriteBatch.DrawString(font, "Ground Floor", new Vector2(HouseWall.X + 40, UpperRowY + PanelHeight + 8), new Color(100, 80, 60));

            foreach (var room in AllRooms)
            {
                DrawRoomPanel(spriteBatch, font, room);
            }
        }

        private void DrawRoomPanel(SpriteBatch spriteBatch, SpriteFont font, BaseRoomType room)
        {
            var bounds = _roomButtons[room].Bounds;
            int level = _playerState.RoomLevels[room];
            bool maxed = level >= MaxRoomLevel;
            bool isHovered = _hoveredRoom == room;

            // Window-style panel: a colored "pane" behind a dark frame with a plus-shaped
            // mullion, so it reads as part of the house instead of a floating UI square.
            Color paneColor = maxed ? new Color(150, 200, 150) : new Color(200, 180, 150);
            if (isHovered && !maxed)
            {
                // Nudge toward white on hover so a clickable panel visibly reacts
                // before the player commits to a click.
                paneColor = Color.Lerp(paneColor, Color.White, 0.18f);
            }

            spriteBatch.FillRectangle(bounds, paneColor);
            spriteBatch.DrawRectangle(bounds, isHovered && !maxed ? new Color(230, 200, 120) : new Color(60, 40, 25), isHovered && !maxed ? 4f : 3f);

            var midX = bounds.X + bounds.Width / 2f;
            var midY = bounds.Y + bounds.Height / 2f;
            spriteBatch.DrawLine(new Vector2(midX, bounds.Y), new Vector2(midX, bounds.Y + bounds.Height), Color.White * 0.35f, 2f);
            spriteBatch.DrawLine(new Vector2(bounds.X, midY), new Vector2(bounds.X + bounds.Width, midY), Color.White * 0.35f, 2f);

            spriteBatch.DrawString(font, room.ToString(), new Vector2(bounds.X + 10, bounds.Y + 8), Color.Black);

            if (maxed)
            {
                spriteBatch.DrawString(font, "MAX", new Vector2(bounds.X + 10, bounds.Y + bounds.Height - 34), Color.Black);
            }
            else
            {
                var (food, planks, scraps) = GetUpgradeCost(room, level);
                bool canAfford = _playerState.Food >= food && _playerState.Planks >= planks && _playerState.Scraps >= scraps;
                // Green when the player can afford the upgrade right now, red when they can't -
                // turns a mental subtraction into an instant glance.
                Color costColor = canAfford ? new Color(40, 110, 40) : new Color(150, 40, 40);

                spriteBatch.DrawString(font, $"Lv {level}/{MaxRoomLevel}", new Vector2(bounds.X + 10, bounds.Y + bounds.Height - 58), Color.Black);
                spriteBatch.DrawString(font, $"{food}F {planks}P {scraps}S", new Vector2(bounds.X + 10, bounds.Y + bounds.Height - 30), costColor);
            }
        }

        private void DrawFooter(SpriteBatch spriteBatch, SpriteFont font)
        {
            if (!string.IsNullOrEmpty(_statusLog))
            {
                spriteBatch.DrawString(font, _statusLog, new Vector2(HouseWall.X + 40, GroundRowY + PanelHeight + 40), Color.DarkRed);
            }
        }

        private void DrawEndDayButton(SpriteBatch spriteBatch, SpriteFont font)
        {
            Color fillColor = _isEndDayHovered ? new Color(130, 95, 60) : new Color(100, 70, 45);
            Color borderColor = _isEndDayHovered ? Color.White : new Color(200, 170, 120);

            spriteBatch.FillRectangle(_endDayButton.Bounds, fillColor);
            spriteBatch.DrawRectangle(_endDayButton.Bounds, borderColor, _isEndDayHovered ? 4f : 3f);

            var textSize = font.MeasureString(_endDayButton.Label);
            var textPos = new Vector2(
                _endDayButton.Bounds.X + (_endDayButton.Bounds.Width - textSize.X) / 2f,
                _endDayButton.Bounds.Y + (_endDayButton.Bounds.Height - textSize.Y) / 2f);
            spriteBatch.DrawString(font, _endDayButton.Label, textPos, Color.White);
        }

        private void DrawHopeBar(SpriteBatch spriteBatch, SpriteFont font)
        {
            spriteBatch.DrawString(font, "Hope", new Vector2(60, 18), Color.Black);

            var barMax = new RectangleF(60, 46, 420, 26);
            var barFill = new RectangleF(60, 46, 420 * (_playerState.Hope / (float)PlayerState.MaxHope), 26);
            spriteBatch.FillRectangle(barMax, Color.Black * 0.3f);
            spriteBatch.FillRectangle(barFill, new Color(200, 60, 140));
            spriteBatch.DrawRectangle(barMax, Color.Black, 2f);

            var label = $"{_playerState.Hope}/{PlayerState.MaxHope}";
            var labelSize = font.MeasureString(label);
            var labelPos = new Vector2(barMax.X + (barMax.Width - labelSize.X) / 2f, barMax.Y + (barMax.Height - labelSize.Y) / 2f);
            spriteBatch.DrawString(font, label, labelPos, Color.Black);
        }

        private void DrawResourceIcons(SpriteBatch spriteBatch, SpriteFont font)
        {
            DrawResourceSlot(spriteBatch, font, 900, "Food", _playerState.Food, DrawFoodIcon, _foodPopTimer);
            DrawResourceSlot(spriteBatch, font, 1010, "Planks", _playerState.Planks, DrawPlanksIcon, _planksPopTimer);
            DrawResourceSlot(spriteBatch, font, 1120, "Scraps", _playerState.Scraps, DrawScrapsIcon, _scrapsPopTimer);
        }

        private void DrawResourceSlot(SpriteBatch spriteBatch, SpriteFont font, float centerX, string label, int value, Action<SpriteBatch, float> drawIcon, float popTimer)
        {
            drawIcon(spriteBatch, centerX);

            // Pop-then-settle: scale jumps up the instant the resource changes, then eases
            // back down to normal over ResourcePopDuration. At rest (popTimer == 0) this is
            // a no-op and renders exactly as before.
            float elapsedRatio = 1f - (popTimer / ResourcePopDuration);
            float decay = 1f - EaseOutCubic(elapsedRatio);
            float popScale = 1f + decay * 0.4f;

            var countText = value.ToString();
            float scale = 1.3f * popScale;
            var countSize = font.MeasureString(countText) * scale;
            spriteBatch.DrawString(font, countText, new Vector2(centerX - countSize.X / 2f, 60), Color.Black, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);

            var labelSize = font.MeasureString(label);
            spriteBatch.DrawString(font, label, new Vector2(centerX - labelSize.X / 2f, 92), new Color(60, 60, 60));
        }

        private static float EaseOutCubic(float t) => 1f - MathF.Pow(1f - t, 3);

        private void DrawFoodIcon(SpriteBatch spriteBatch, float centerX)
        {
            FillCircleApprox(spriteBatch, new Vector2(centerX, 36), 16f, new Color(190, 60, 50));
        }

        private void DrawPlanksIcon(SpriteBatch spriteBatch, float centerX)
        {
            for (int i = 0; i < 3; i++)
            {
                var plankRect = new RectangleF(centerX - 22, 22 + i * 10, 44, 7);
                spriteBatch.FillRectangle(plankRect, new Color(160, 110, 60));
            }
        }

        private void DrawScrapsIcon(SpriteBatch spriteBatch, float centerX)
        {
            spriteBatch.FillRectangle(new RectangleF(centerX - 16, 20, 32, 32), new Color(150, 150, 160));
            spriteBatch.FillRectangle(new RectangleF(centerX - 6, 30, 18, 14), new Color(95, 95, 105));
        }

        

        private static void FillTriangle(SpriteBatch spriteBatch, Vector2 apex, Vector2 baseLeft, Vector2 baseRight, Color color, int slices = 48)
        {
            float topY = apex.Y;
            float bottomY = baseLeft.Y;
            float height = bottomY - topY;
            if (height <= 0) return;

            for (int i = 0; i < slices; i++)
            {
                float t0 = i / (float)slices;
                float t1 = (i + 1) / (float)slices;
                float y0 = MathHelper.Lerp(topY, bottomY, t0);
                float y1 = MathHelper.Lerp(topY, bottomY, t1);

                float leftEdge = Math.Min(MathHelper.Lerp(apex.X, baseLeft.X, t0), MathHelper.Lerp(apex.X, baseLeft.X, t1));
                float rightEdge = Math.Max(MathHelper.Lerp(apex.X, baseRight.X, t0), MathHelper.Lerp(apex.X, baseRight.X, t1));

                spriteBatch.FillRectangle(new RectangleF(leftEdge, y0, rightEdge - leftEdge, y1 - y0 + 1f), color);
            }
        }

        private static void FillCircleApprox(SpriteBatch spriteBatch, Vector2 center, float radius, Color color, int slices = 20)
        {
            for (int i = 0; i < slices; i++)
            {
                float t0 = i / (float)slices;
                float t1 = (i + 1) / (float)slices;
                float y0 = MathHelper.Lerp(-radius, radius, t0);
                float y1 = MathHelper.Lerp(-radius, radius, t1);
                float yMid = (y0 + y1) / 2f;
                float halfWidth = (float)Math.Sqrt(Math.Max(0f, radius * radius - yMid * yMid));

                spriteBatch.FillRectangle(new RectangleF(center.X - halfWidth, center.Y + y0, halfWidth * 2f, y1 - y0 + 1f), color);
            }
        }
    }
}